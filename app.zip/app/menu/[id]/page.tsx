import { db } from "@/db";
import { menuItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import IngredientDetailClient from "./IngredientDetailClient";

export const dynamic = "force-dynamic";

export default async function MenuItemPage({
  params,
}: {
  params: { id: string };
}) {
  const [item] = await db
    .select()
    .from(menuItems)
    .where(eq(menuItems.id, Number(params.id)));

  if (!item) notFound();

  return (
    <main className="min-h-screen bg-[#0a0a0a] text-[#E8E2D6] px-6 py-16 sm:px-12">
      <div className="max-w-2xl mx-auto">
        <Link
          href="/menu"
          className="font-serif text-xs tracking-[0.3em] text-[#C9A66B] hover:text-[#F1E9D8] transition-colors"
        >
          ← MENU
        </Link>
        <div className="mt-8">
          <IngredientDetailClient item={item} />
        </div>
      </div>
    </main>
  );
}
