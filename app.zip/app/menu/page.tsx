import { db } from "@/db";
import { menuItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";
import Image from "next/image";

export const dynamic = "force-dynamic";

const CATEGORY_LABELS: Record<string, string> = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  dinner: "Dinner",
  drinks: "Drinks",
  desserts: "Desserts",
};

const CATEGORY_ORDER = ["breakfast", "lunch", "dinner", "drinks", "desserts"];

const CATEGORY_IMAGES: Record<string, string> = {
  breakfast: "/images/categories/breakfast.png",
  lunch: "/images/categories/lunch.png",
  dinner: "/images/categories/dinner.png",
  drinks: "/images/categories/drinks.png",
  desserts: "/images/categories/desserts.jpg",
};

export default async function MenuPage() {
  const items = await db
    .select()
    .from(menuItems)
    .where(eq(menuItems.available, true));

  const grouped = CATEGORY_ORDER.map((cat) => ({
    category: cat,
    label: CATEGORY_LABELS[cat],
    image: CATEGORY_IMAGES[cat],
    items: items.filter((i) => i.category === cat),
  })).filter((group) => group.items.length > 0);

  return (
    <main className="min-h-screen bg-[#0a0a0a] text-[#E8E2D6]">
      <div className="px-6 py-10 sm:px-12">
        <Link
          href="/"
          className="font-serif text-xs tracking-[0.3em] text-[#C9A66B] hover:text-[#F1E9D8] transition-colors"
        >
          ← AHADU
        </Link>
        <h1 className="font-serif text-4xl tracking-[0.2em] mt-8">MENU</h1>
      </div>

      {grouped.map((group) => (
        <section key={group.category} className="mb-4">
          {/* category banner */}
          <div className="relative h-56 sm:h-64 overflow-hidden">
            {group.image ? (
              <>
                <Image
                  src={group.image}
                  alt=""
                  fill
                  className="object-cover"
                  style={{
                    filter: "grayscale(0.35) sepia(0.25) brightness(0.55) contrast(1.05)",
                  }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "linear-gradient(180deg, rgba(10,10,10,0.3) 0%, rgba(10,10,10,0.75) 100%)",
                  }}
                />
              </>
            ) : (
              <div className="absolute inset-0 bg-[#161412]" />
            )}
            <div className="relative z-10 h-full flex items-center px-6 sm:px-12">
              <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.25em] text-[#F1E9D8]">
                {group.label.toUpperCase()}
              </h2>
            </div>
          </div>

          {/* items */}
          <div className="px-6 py-10 sm:px-12">
            <div className="grid gap-4 sm:grid-cols-2 max-w-5xl">
              {group.items.map((item) => (
                <Link
                  key={item.id}
                  href={`/menu/${item.id}`}
                  className="block border border-[#2a241a] rounded-sm p-5 hover:border-[#C9A66B]/50 transition-colors font-serif"
                >
                  <div className="flex justify-between items-start gap-3">
                    <h3 className="text-[#F1E9D8] tracking-wide">{item.name}</h3>
                    <span className="text-sm text-[#C9A66B] whitespace-nowrap">
                      ${(item.price / 100).toFixed(2)}
                    </span>
                  </div>
                  <p className="text-sm text-[#8A8172] mt-2 leading-relaxed">
                    {item.description}
                  </p>
                  {item.dietaryTags.length > 0 && (
                    <div className="flex gap-2 flex-wrap mt-3">
                      {item.dietaryTags.map((tag) => (
                        <span
                          key={tag}
                          className="text-[10px] tracking-wider px-2 py-0.5 rounded-full border border-[#3a3226] text-[#8A8172]"
                        >
                          {tag.toUpperCase()}
                        </span>
                      ))}
                    </div>
                  )}
                </Link>
              ))}
            </div>
          </div>
        </section>
      ))}
    </main>
  );
}
