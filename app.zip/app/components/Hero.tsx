"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";

const NAV = [
  { label: "Reservations", href: "/reservations" },
  { label: "Menu", href: "/menu" },
  { label: "Gallery", href: "/gallery" },
];

export default function Hero() {
  const [stage, setStage] = useState<"dark" | "logo" | "nav">("dark");
  const [cursor, setCursor] = useState({ x: 50, y: 50 });

  useEffect(() => {
    const t1 = setTimeout(() => setStage("logo"), 300);
    const t2 = setTimeout(() => setStage("nav"), 1500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  useEffect(() => {
    function handleMove(e: MouseEvent) {
      setCursor({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      });
    }
    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, []);

  return (
    <main className="relative min-h-screen overflow-hidden bg-black flex flex-col items-center justify-center">
      {/* real photo background */}
      <Image
        src="/images/hero-bg.png"
        alt=""
        fill
        priority
        className="object-cover"
      />

      {/* darkening overlay so the wordmark and nav stay legible over the photo */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(8,6,3,0.55) 0%, rgba(8,6,3,0.35) 30%, rgba(8,6,3,0.55) 60%, rgba(6,5,3,0.8) 100%)",
        }}
      />

      {/* cursor-following glow */}
      <div
        className="pointer-events-none absolute inset-0 transition-[background] duration-300 ease-out"
        style={{
          background: `radial-gradient(circle 420px at ${cursor.x}% ${cursor.y}%, rgba(224,180,110,0.14) 0%, rgba(224,180,110,0) 70%)`,
        }}
      />

      {/* vignette to keep focus centered */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.5) 100%)",
        }}
      />

      <div className="relative z-10 flex flex-col items-center px-6">
        <h1
          className={`font-serif text-[clamp(2.5rem,8vw,5.5rem)] tracking-[0.35em] text-[#F1E9D8] transition-all duration-[1400ms] ease-out ${
            stage === "dark"
              ? "opacity-0 translate-y-6 blur-sm"
              : "opacity-100 translate-y-0 blur-0"
          }`}
          style={{
            textShadow:
              stage !== "dark"
                ? "0 0 40px rgba(224,180,110,0.35), 0 0 90px rgba(0,0,0,0.6)"
                : "none",
          }}
        >
          AHADU
        </h1>

        <p
          className={`mt-6 font-serif italic text-base tracking-wide text-[#D8BE8F] transition-all duration-[1400ms] ease-out ${
            stage === "dark" ? "opacity-0" : "opacity-90"
          }`}
        >
          The table is set. Come as you are, stay for the evening.
        </p>

        <nav className="mt-14 flex flex-col items-center gap-6">
          {NAV.map((item, i) => (
            <Link
              key={item.href}
              href={item.href}
              className={`font-serif text-lg tracking-[0.3em] text-[#E8CFA0] hover:text-[#F1E9D8] transition-all duration-700 ease-out ${
                stage === "nav"
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-3"
              }`}
              style={{
                transitionDelay: stage === "nav" ? `${i * 150}ms` : "0ms",
                textShadow: "0 2px 12px rgba(0,0,0,0.8)",
              }}
            >
              {item.label.toUpperCase()}
            </Link>
          ))}
        </nav>
      </div>
    </main>
  );
}
